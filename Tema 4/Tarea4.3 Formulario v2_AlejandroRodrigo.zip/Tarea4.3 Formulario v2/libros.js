//Usamos el Map PARA GUARDAR LOS LIBROS: CLAVE = TITLE, valor = author, year

const libros = new Map();

const title = document.getElementById("title");
const author = document.getElementById("author");
const year = document.getElementById("year");
const listalibros = document.getElementById("lista-libros");

document.getElementById("saveButton").addEventListener("click", (e) => 
    { e.preventDefault();// Con esto Prevenimos el envío del formulario

if (title.value === "" || author.value === "" || year.value === "" || title.value === " " || author.value === " " || year.value === " " ) {
    alert("Por favor, complete todos los campos.");
    return;
    }//if 

    //Guardamos el libro en el Map
    
    libros.set(title.value, {author: author.value, year: year.value});

    //Limpiamos los campos del formulario
    title.value = "";
    author.value = "";
    year.value = "";

    alert("Libro guardado correctamente.");

}); //documentTimeline saveButton

document.getElementById("showButton").addEventListener("click", (e) => {
    e.preventDefault();// Con esto Prevenimos el envío del formulario

    //Limpiamos la lista antes de mostrar los libros
    listalibros.innerHTML = "";

    //Verificamos si hay libros guardados
    
    if (libros.size === 0) {
    alert("No hay libros guardados.");
    return;
    }//if

    //Mostramos los libros guardados
    const orderedlist = Array.from(libros.keys()).sort();

    //Creamos elementos para cada libro y los añadimos a la lista
    orderedlist.forEach((title) => {
    const libro = libros.get(title)
    const div = document.createElement("div");
    div.textContent = `Título: ${title}, Autor: ${libro.author}, Año: ${libro.year}`;
    listalibros.appendChild(div);
    });


});//documentTimeline showButton