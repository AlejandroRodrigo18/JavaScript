function game() {

      let numeroAdivinar = Math.floor(Math.random() * 100) + 1;
      let intentos = 0;
      let juegoCancelado = false;
      
    while (true) {
        let entrada = prompt("Adivina el número (entre 1 y 100):");

        if (entrada == null) {
          alert("Juego cancelado.");
          juegoCancelado = true;
          break;
        }
        let numero = parseInt(entrada);

        if (isNaN(entrada)) {
          alert("Eso no es un número. Introduce un número correcto.");
          continue;
        }

        intentos++;

        if (numero == numeroAdivinar) {
          alert("¡Correcto! El número era " + numeroAdivinar + ". Lo lograste en " + intentos + " intento(s).");
          break;
        } else if (numero < numeroAdivinar) {
          alert("El número es mayor.");
        } else {
          alert("El número es menor.");
        }
      }

      if (!juegoCancelado) {
        let jugarDeNuevo = confirm("¿Quieres jugar otra vez?");

        if (jugarDeNuevo) {
          iniciarJuego();
        } else {
          alert("Gracias por jugar. ¡Nos vemos!");
        }

      }
    }