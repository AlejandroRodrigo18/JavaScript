function data(){

    let nombre = document.getElementById("name").value;
    let apellido = document.getElementById("lname").value;
    let salario = document.getElementById("salar").value;
    let edad = document.getElementById("age").value;

   

      if (salario < 1000 && edad <= 30) {
        salario = 1100;
        alert(nombre + " " + apellido + " con edad de " + edad + " gana un salario de " + salario.toFixed(2));
    } else if (salario >= 2000 && edad > 45) {
        salario = salario * 1.03;
        alert(nombre + " " + apellido + " con edad de " + edad + " gana un salario de " + salario.toFixed(2));
    } else if ((salario <= 2000 && salario >= 1000) && edad <= 45) {
        salario = salario * 1.10;
        alert(nombre + " " + apellido + " con edad de " + edad + " gana un salario de " + salario.toFixed(2));
    } else if(edad > 45){
        salario = salario*1.15;
        alert(nombre + " " + apellido + " con edad de " + edad + " gana un salario de " + salario.toFixed(2));
    }else if (edad >= 30 && edad <= 45){
        salario = salario*1.03;
        alert(nombre + " " + apellido + " con edad de " + edad + " gana un salario de " + salario.toFixed(2));
    } 

}