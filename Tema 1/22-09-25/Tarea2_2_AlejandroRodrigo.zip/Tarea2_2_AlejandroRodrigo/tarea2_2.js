const colors = ["lightblue", "pink", "yellow", "lightgreen"];

const randomColor = colors[Math.floor(Math.random() * colors.length)];

document.body.style.backgroundColor = randomColor;
