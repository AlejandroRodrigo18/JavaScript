function datos(){

            let datat = document.getElementById("fname").value;

    if(isNaN(datat) ){

     alert("El dato introducudo es un carácter " + "(" + datat + ")");
     

    } else{

     alert("El dato introducudo es un número " + "("+ datat+ ")");
    }
     
}